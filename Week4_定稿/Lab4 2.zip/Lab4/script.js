const form = document.myForm;

const regExName = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
const regExEmail =
  /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@northeastern\.edu$/;
const regExPhone =
  /^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/;
const regExZip = /^[0-9]{5}(?:-[0-9]{4})?$/;
const regExAlphaNumeric = /^[a-zA-Z0-9]+$/;

let isNameValid = false;
let isEmailValid = false;
let isPhoneNumberValid = false;
let isZipValid = false;
let isCommentValid = false;

const validate = (e) => {
  let { id, name, value } = e.target;

  if (!value.trim()) {
    document.getElementById(`error_${name}`).innerText =
      "Field cannot be empty.";
    document.getElementById(`error_${name}`).style.display = "block";
    return;
  }
  if (value.length < 2) {
    document.getElementById(`error_${name}`).innerText =
      "Field should have at least 2 characters.";
    document.getElementById(`error_${name}`).style.display = "block";
    return;
  }
  if (value.length > 50) {
    document.getElementById(`error_${name}`).innerText =
      "Field should not exceed 50 characters.";
    document.getElementById(`error_${name}`).style.display = "block";
    return;
  }

  if (name == "name") {
    if (!value.trim().toLowerCase().match(regExName)) {
      document.getElementById(`error_${name}`).style.display = "block";
      isNameValid = false;
    } else {
      document.getElementById(`error_${name}`).style.display = "none";
      isNameValid = true;
    }
  } else if (name == "email") {
    if (!value.trim().toLowerCase().match(regExEmail)) {
      document.getElementById(`error_${name}`).style.display = "block";
      isEmailValid = false;
    } else {
      document.getElementById(`error_${name}`).style.display = "none";
      isEmailValid = true;
    }
  } else if (name == "phoneNumber") {
    if (!value.trim().toLowerCase().match(regExPhone)) {
      document.getElementById(`error_${name}`).style.display = "block";
      isPhoneNumberValid = false;
    } else {
      document.getElementById(`error_${name}`).style.display = "none";
      isPhoneNumberValid = true;
    }
  } else if (name == "zip") {
    if (!value.trim().toLowerCase().match(regExZip)) {
      document.getElementById(`error_${name}`).style.display = "block";
      isZipValid = false;
    } else {
      document.getElementById(`error_${name}`).style.display = "none";
      isZipValid = true;
    }
  }

  if (!isNameValid || !isEmailValid || !isPhoneNumberValid || !isZipValid) {
    document.myForm.submit.setAttribute("disabled", true);
  } else {
    document.myForm.submit.removeAttribute("disabled");
  }
};

form.addEventListener("input", validate);
